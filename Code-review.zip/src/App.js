import './App.css';
import Dashboard from './Dashboard';
function App() {
  return (
    <div className="App">
     <h1>Code review</h1>
     <Dashboard/>
    </div>
  );
}

export default App;
