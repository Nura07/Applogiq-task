import React from "react";
import './Card.css';
const Card =({card, handleCardClick, isFlipped})=>{
    return(
    <>
    {/* <h1>Card Component</h1> */}
    <div className={`card ${isFlipped ? 'flipped':''}`} onClick={handleCardClick}>
        {isFlipped ? card.value : 'click me'}
    </div>
    </>
    )

}

export default Card;
