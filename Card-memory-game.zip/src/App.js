import { useEffect, useState } from 'react';
import './App.css';
import Card from './Card';

const cardData = [
  { id: 1, value: '🐶' },
  { id: 2, value: '🐱' },
  { id: 3, value: '🐭' },
  { id: 4, value: '🐹' },
  { id: 5, value: '🐰' },
  { id: 6, value: '🦊' },
  { id: 7, value: '🐻' },
  { id: 8, value: '🐼' }
];

function App() {
  const [cards, setCards] = useState([]);
  const [flippedcards, setFlippedCards] = useState([])
  const [matchedcards, setMatchedCards] = useState([]);

  useEffect(()=>{
    const fullCards = [...cardData,...cardData].sort(()=>Math.random()-0.5);
    setCards(fullCards);
  },[]);

  const handleCardClick = (card) =>{
    if(flippedcards.length <2 && !flippedcards.includes(card.id)){
      setFlippedCards([...flippedcards,card.id]);
    }
  }

  useEffect(()=>{
    if(flippedcards.length===2){
      const [firstcardId, secondcardId] = flippedcards;
      const firstcard = cards.find(card => card.id === firstcardId);
      const secondcard = cards.find(card => card.id === secondcardId);

      if(firstcard.value === secondcard.value){
        setMatchedCards([...matchedcards,firstcardId,secondcardId]);
      }

      const timer = setTimeout(()=>{
        setFlippedCards([]);
      },2000)
      
      return ()=> clearTimeout(timer);
    }
  },[flippedcards,cards,matchedcards]);

  return (
    <div className="game">
      {/* <h1>Game Component</h1> */}
      {cards.map(card=>(
          <Card key={card.id} card = {card} handleCardClick={()=>handleCardClick(card)}
            isFlipped = {flippedcards.includes(card.id) || (matchedcards.includes(card.id))}
          
          />
        ))}
      {matchedcards.length ===cards.length &&<div className='winner'>You Win the Game</div>}
    </div>
    
  );
}

export default App;
